/*!
Undocumented PECOFF seems like a good source of edge cases:

https://media.blackhat.com/bh-us-11/Vuksan/BH_US_11_VuksanPericin_PECOFF_WP.pdf
*/

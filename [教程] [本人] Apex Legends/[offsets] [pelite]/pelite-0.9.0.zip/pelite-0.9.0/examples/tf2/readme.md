Demonstrates static analysis by dumping Team Fortress 2 offsets.

See the output in [stdout.txt](stdout.txt).
